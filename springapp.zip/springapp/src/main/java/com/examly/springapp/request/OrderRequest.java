package com.examly.springapp.request;

public class OrderRequest {
	    
	    private int quantity;
	    private String username;

	    public int getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(int quantity) {
	        this.quantity = quantity;
	    }

	    public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
	        this.username = username;
	    }



	}
